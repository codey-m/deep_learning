# PCA and autoencoder image-compression demo

Open `PCA_Autoencoder_Demo.ipynb` and run “Open comparison.” Its setup cell is configured as a collapsed form in Colab and has hidden-source metadata for JupyterLab; the code remains expandable. Other notebook viewers may display the source differently. The browser companion has no code cell at all.

The comparison opens on `cat_03`, with thumbnail buttons for all eight selected photos and no separate opening-example walkthrough. The main notebook keeps the PCA projection and weighted-reconstruction formulas, the autoencoder mapping, and the stored-byte formula. The outer-product view follows the PCA projection and weighted-reconstruction formulas, including the single-image projection and batch-reconstruction formulations.

## The three settings

The precision options are exactly 2-bit integers, 4-bit integers, and float32. Four-bit storage remains the intermediate case for the downstream quantization discussion.

The main matched-byte-budget view allocates the same per-image payload to both methods:

| Bytes per image | PCA float32 coefficients | TAESD precision across 1,024 values |
|---:|---:|---:|
| 256 | 64 | 2 bits |
| 512 | 128 | 4 bits |
| 4,096 | 1,024 | 32 bits |

Changing the coefficient setting changes both reconstructions. PCA varies its retained coefficient count; TAESD varies its stored precision. The fitted PCA basis and TAESD architecture are unchanged. The comparison matches per-image bytes, while their logical shapes and shared reconstruction costs remain explicit.

The precision view instead keeps both at 1,024 values and changes both to the same selected precision. This isolates precision changes from dimension changes. Image switching preserves the current settings.

## Run the presentation

Unzip `PCA_Autoencoder_Demo.zip` and keep `pca_autoencoder_demo.html` beside the notebook. The presentation uses saved results and needs only a standard notebook runtime with IPython. It does not load models or require a GPU, NumPy, or PyTorch.

In Colab, upload the notebook and run its launch cell. If the companion file is missing, the cell asks for the lightweight ZIP and extracts it. This upload path has not been tested in a real Colab session.

Alternatively, open `pca_autoencoder_demo.html` directly in a browser. It is self-contained and works offline. Model details and credits are inside the comparison.

## Optional model code

`Model_Operations.ipynb` preserves the detailed executable code in a separate reference, with `cat_03` as its default image. Run it from `PCA_Autoencoder_Full.zip`, which includes the fitted PCA basis, TAESD weights, calibration ranges, and formatting helper. Its four-bit example computes and decodes an actual 512-byte packed payload.

The optional reference requires NumPy, PyTorch, Pillow, and IPython; see `requirements-models.txt`. The full package contains the 201.5 MB fitted PCA basis and about 9.8 MB of TAESD weights. The main presentation works without these large assets.

## Quantization reveal for the TA

In the precision view, compare float32 with four-bit storage before showing two-bit storage. Ask what visible evidence changes while the per-image payload falls from 4,096 to 512 bytes. On these eight images, the TAESD mean RMSE is about 12.88 for float32, 14.03 for four-bit storage, and 29.60 for two-bit storage. Keep that observed result for the discussion rather than announcing it before the comparison.

## Source and cost accounting

PCA was fitted on 2,048 Open Images photos. Another 128 calibrated quantization ranges. The eight display source IDs were excluded from both collections. TAESD uses its author's pretrained weights and a different training history. This illustrates the fitted models; it does not isolate architecture or establish representative quality. Original TAESD training overlap with public images was not audited.

The raw uint8 RGB input contains 49,152 bytes. At 1,024 float32 values, the value count falls by 48:1 and the per-image byte payload falls by 12:1. Integer codes are actually packed, read back, unpacked, and dequantized. Values outside the calibration range are clipped.

Shared reconstruction costs are separate from the matched payload: PCA basis and mean vary with coefficient count; the TAESD decoder parameters occupy 4,890,124 bytes. Integer quantization uses 8,192 shared range bytes per encoded method. These costs are reported in the comparison. PNG display-file sizes are separate from encoded representation sizes.

`CREDITS.md`, `results.csv`, and `provenance.json` record photo credits, raw results, model revision, and weight hashes. The presentation uses 64 relevant saved reconstructions from the larger unchanged 112-result preparation set. The original broader coefficient/precision data remain available in the workspace; the 1,536-coefficient exploration has not changed the fitted notebook model.

RMSE is computed on decoded RGB values clipped to [0,1], before PNG rounding, and displayed on the 0 to 255 channel scale.

## Verification

The compact notebook and optional model reference passed fresh local kernel execution. Checks verified the collapsed setup metadata, the restored outer-product identities, correct initial cat, all eight thumbnail choices, the three precision options, and all 48 image/mode/setting states. Both methods have equal per-image byte payloads in every displayed comparison.

The earlier unchanged numerical checks cover all 112 pixel errors, displayed PNG values, physical payload lengths, independent low-bit unpacking, and disjoint source IDs. Native Chrome showed the cat-default layout before the final budget-control refinement. The final controls were tested against a DOM implementation. Final visual rendering, MathML/LaTeX layout, canvas detail zoom, real Colab behavior, and screen-reader behavior remain unverified.

Workspace build sources are in `../build/`. Course repositories were not changed and nothing was published.
